using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerHealthSystem : MonoBehaviour
{
    // Defining all public and private variables from the healthsystem itself.
    public float MaxHealth = 100f;
    public float Health;
    public bool playerIsAlive;

    // Defining all public and private variables that refer to different GameObjects.
    public GameObject diedScreen;
    public GameObject aliveScreen;
    public TextMeshProUGUI TextPro;

    void Start()
    {
        // Define the 2 different UI screens for when the player is alive or dead.
        diedScreen =  GameObject.Find("Died Screen");
        aliveScreen = GameObject.Find("Alive Screen");
        diedScreen.SetActive(false);
        aliveScreen.SetActive(true);
        Health = MaxHealth;
    }

    void Update()
    {
        //Updating the health amount on the UI;
        TextPro.text = Health + "/" + MaxHealth;
        if (Health <= 0)
        {
            Die();
        }  
    }

    void Die() {
        // Setting the playerIsActive bool to false so the GunScript knows the player is dead, and wont make any sounds or play any animations.
        playerIsAlive = false;
        GameObject.Find("sniper rifle 2_prefab").GetComponent<GunScript>().checkIfPlayerIsAlive = playerIsAlive;

        // Remove mouse lock so the player cant click on the UI buttons. 
        Cursor.lockState = CursorLockMode.None;
        aliveScreen.SetActive(false);
        diedScreen.SetActive(true);

        // Freeze the game on the background.
        Time.timeScale = 0;
    }

}
