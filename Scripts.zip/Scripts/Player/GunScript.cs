using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class GunScript : MonoBehaviour
{
    // Defining all public and private variables from the gun itself.
    public float damage;
    public float range;
    public float firerate = 0.2f;
    public float canfire = 0.2f;
    public int Ammo = 300;
    public int currentAmmoShot = 0;
    public float AmmoInClip = 50;
    public bool NeedToReload = false;
    public bool NoMoreAmmo = false;
    public bool reloading;
    public bool checkIfPlayerIsAlive;


    // Defining all public and private variables that refer to different GameObjects.
    public PlayerHealthSystem PlayerHealthSystem;
    public AudioSource GunFire;
    public AudioSource OutOfAmmo;
    public AudioSource ReloadAudio;
    private GameObject ImpactGO;
    public Camera cam;
    public GameObject camHolder;
    public ParticleSystem muzzleflash;
    public GameObject impactEffectNormal;
    public GameObject impactEffectBlood;
    public GameObject BulletHole;
    public GameObject Gun;
    private Animator MAnimator;
    public TextMeshProUGUI TextPro;
    public LayerMask IgnoreMe;
    
    // Define the different layers for the Raycast to check from.
    private int zombie;
    private int zombieHead;
    private int level;
    private int objective;


    void Start(){
        checkIfPlayerIsAlive = true;
        MAnimator = gameObject.GetComponent<Animator>();
        
        // Set the different layers the actual layers in the game.
        zombie = LayerMask.NameToLayer("zombie");
        zombieHead = LayerMask.NameToLayer("zombieHead");
        level = LayerMask.NameToLayer("level");
        objective = LayerMask.NameToLayer("objective");
    }

    // Update is called once per frame
    void Update()
    {   
        if (checkIfPlayerIsAlive)
        {
            // Update ammo count on UI.
            TextPro.text = AmmoInClip + "/" + Ammo;

            if ( Ammo <= 0)
            {
                // If ammo is lower then 0, then set value to 0 to prevent having -2 bulets for instance.
                Ammo = 0;
                NoMoreAmmo = true;
            }
            
            // FIRE RAYCAST:
            // Fire Raycast add the fire rate speed of the every time the player presses the left mouse button.
            if( Input.GetButton("Fire1") && Time.time > canfire && !NeedToReload && AmmoInClip != 0 && !Input.GetKey(KeyCode.LeftShift))
            { 
                //Play sound effect and Shoot function.
                GunFire.Play();
                Shoot(); 
                canfire = Time.time + firerate;
            } 

            //Play OutOfAmmo sound effect when the player needs to reload or has no ammo at all.
            if (Input.GetButtonDown("Fire1") && !reloading && !Input.GetKey(KeyCode.LeftShift))
            {
                if (NeedToReload)
                {
                    OutOfAmmo.Play();
                } 
                else if (AmmoInClip == 0)
                {
                    OutOfAmmo.Play();
                }
                else
                {
                    return;
                }
            }

            // ANIMATIONS:
            // Reload when player is not running, this makes it harder for the player.
            if (Input.GetKeyDown(KeyCode.R) && !Input.GetKey(KeyCode.LeftShift))
            {   
                if (!NoMoreAmmo)
                {
                    if (!ReloadAudio.isPlaying) {
                        ReloadAudio.Play();
                    }

                    reloading = true;

                    // Start reload animation and Coroutine so the player can only shoot when he has finished reloading.
                    MAnimator.SetTrigger("Reload");
                    StartCoroutine(FinishReloading());
                }

            }


            if (Input.GetMouseButton(1))
            {   
                // Reset other animation triggers for smooth transitions.
                MAnimator.ResetTrigger("Walk");
                MAnimator.ResetTrigger("idle");

                MAnimator.SetTrigger("ADS"); 
            }
            
            if (Input.GetMouseButtonUp(1))
            {
                // Reset other animation triggers for smooth transitions.
                MAnimator.ResetTrigger("ADS"); 

                MAnimator.SetTrigger("stop ADS");
            }


            //Fire when Mouse0 (left) is pressed
            if (Input.GetKey(KeyCode.Mouse0) && !Input.GetKey(KeyCode.Mouse1) && !Input.GetKeyDown(KeyCode.R) && !NeedToReload && AmmoInClip != 0 && !Input.GetKey(KeyCode.LeftShift))
            {   
                // Reset other animation triggers for smooth transitions.
                MAnimator.ResetTrigger("Walk");
                MAnimator.ResetTrigger("idle");
                MAnimator.ResetTrigger("Run");

                MAnimator.SetTrigger("Fire"); 
            }

            // Fire while aiming down site of left and right button is pressed, and the player is not running or reloading.
            if (Input.GetKey(KeyCode.Mouse0) && Input.GetKey(KeyCode.Mouse1) && !Input.GetKey(KeyCode.LeftShift) && !NeedToReload && AmmoInClip != 0)
            {   
                // Reset other animation triggers for smooth transitions.
                MAnimator.ResetTrigger("Walk");
                MAnimator.ResetTrigger("idle");
                MAnimator.ResetTrigger("Run");

                MAnimator.SetTrigger("Fire ADS"); 
            }


            //Stop firing when Mouse0 (Left) is released
            if(Input.GetKeyUp(KeyCode.Mouse0) && !Input.GetKey(KeyCode.Mouse1))
            {
                // Reset other animation triggers for smooth transitions.
                MAnimator.ResetTrigger("Walk");
                MAnimator.ResetTrigger("Fire"); 
                MAnimator.ResetTrigger("Fire ADS");
                MAnimator.ResetTrigger("stop ADS");
                MAnimator.ResetTrigger("ADS");

                MAnimator.SetTrigger("idle");
            }

            // Stop firing but still aim down sight when left mouse button is released, but right mouse button is still pressed.
            if(Input.GetKeyUp(KeyCode.Mouse0) && Input.GetKey(KeyCode.Mouse1))
            {
                // Reset other animation triggers for smooth transitions.
                MAnimator.ResetTrigger("idle");
                MAnimator.ResetTrigger("Fire ADS");
                MAnimator.ResetTrigger("Fire"); 

                MAnimator.SetTrigger("ADS");
            }
        }
    }

    void Shoot()
    {
        // Increase amount of ammo shot, so the ammo system knows how many bullets to remove from the players total bullet ammount.
        currentAmmoShot ++;

        // Decrease ammo in clip.
        AmmoInClip--;

        // Set NeedToReload bool to true when the player has shot the entire clip.
        if (currentAmmoShot >= 50){
            NeedToReload = true;
        }

            muzzleflash.Play();
            RaycastHit hit;
            if (Physics.Raycast(cam.transform.position, cam.transform.forward, out hit, range, ~IgnoreMe))
            {
                // Check if the raycast hit a GameObject with a parent. This is needed because only the the children of the zombie prefab have MeshColliders.
                if(hit.transform.parent != null) {

                    // Get script component from target, depending on wich enemy the raycast hit.
                    ZombieAI target = hit.transform.parent.GetComponent<ZombieAI>();
                    EndObjectiveScript target2 = hit.transform.parent.GetComponent<EndObjectiveScript>();

                    // Increase damage amount when the raycast hits the zombies head.
                    if (hit.transform.gameObject.layer == zombieHead)
                    {
                        damage = 50;
                        if (target != null)
                        {
                        target.TakeDamage(damage);
                        }

                        ImpactGO = Instantiate(impactEffectBlood, hit.point, Quaternion.LookRotation(hit.normal));
                    }
                    // Set the damage amount to normal if the raycast hits the zombies body.
                    else if (hit.transform.gameObject.layer == zombie)
                    {
                        damage = 10;
                        if (target != null)
                        {
                        target.TakeDamage(damage);
                        }

                        // instantiate blood effect with the rotation of the Raycast.
                        ImpactGO = Instantiate(impactEffectBlood, hit.point, Quaternion.LookRotation(hit.normal));
                    } 
                    else if (hit.transform.gameObject.layer == level)
                    {
                        Instantiate(BulletHole, hit.point + (hit.normal * .0f), Quaternion.LookRotation(hit.normal));
                        ImpactGO = Instantiate(impactEffectNormal, hit.point, Quaternion.LookRotation(hit.normal));
                    }
                    else if (hit.transform.gameObject.layer == objective)
                    {

                        target2.TakeDamage(damage);

                        // Instantiatie bullethole and particle effect if the Raycast hit the objective.
                        Instantiate(BulletHole, hit.point + (hit.normal * .0f), Quaternion.LookRotation(hit.normal));
                        ImpactGO = Instantiate(impactEffectNormal, hit.point, Quaternion.LookRotation(hit.normal));
                    }
                } 

                // Desroy bulletholes and particle effects after a few seconds to improve performance.
                Destroy(ImpactGO, 2f);
            }
    }

    IEnumerator FinishReloading()
    {
        //Wait for 2 seconds
        yield return new WaitForSeconds(2);

        // Reset the variables for the ammo sytem.
        NeedToReload = false;
        Ammo -= currentAmmoShot;
        currentAmmoShot = 0;
        reloading = false;
        AmmoInClip = 50;
    }
}
