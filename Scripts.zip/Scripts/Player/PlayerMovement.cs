using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerMovement : MonoBehaviour
{
    // Defining all public and private variables from the player itself.
    public float Movementspeed = 3f;
    public float gravity = -9.81f;
    public float jumpHeight = 1f;


    // Defining all public and private variables that refer to different GameObjects.
    public Transform player;
    private Animator MAnimator;
    private Animator BodyAnimator;
    public GameObject CamHolder;
    public GameObject Rifle;
    public CharacterController controller;
    public Vector3 velocity;


    void Start()
    {
        // Define the animators used for the player movement.
        MAnimator = Rifle.GetComponent<Animator>();
        BodyAnimator = CamHolder.GetComponent<Animator>();
    }

    // Update is called once per frame.
    void Update()
    {    

        // Check if player is on the ground. We need to do this to prevent the player from jumping whilst in air.
        if (controller.isGrounded && velocity.y < 0f)
        {
            velocity.y = -2f;
        }

        // Jump when spacebar is pressed and player is on the ground.
        if (Input.GetButtonDown("Jump") && controller.isGrounded)
        {
            velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
        }

        // Push player downwards at al times to make its rigidbody fall to the ground after jumping.
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");


        Vector3 move = transform.right * x + transform.forward * z;

        // move the player with the current movement speed.
        controller.Move(move * (Movementspeed) * Time.deltaTime);


        if (Input.GetKey(KeyCode.Q) && !Input.GetKey(KeyCode.LeftShift))
        {   
            // Set leaning trigger and reset other triggers to make sure there is a smooth transition.
            MAnimator.ResetTrigger("Run");
            BodyAnimator.ResetTrigger("Lean Right"); 
            BodyAnimator.ResetTrigger("Idle Camera"); 

            BodyAnimator.SetTrigger("Lean Left");
        } 

        if (Input.GetKey(KeyCode.E) && !Input.GetKey(KeyCode.LeftShift))
        {   
            // Set leaning trigger and reset other triggers to make sure there is a smooth transition.
            MAnimator.ResetTrigger("Run");
            BodyAnimator.ResetTrigger("Lean Left"); 
            BodyAnimator.ResetTrigger("Idle Camera"); 

            BodyAnimator.SetTrigger("Lean Right");
        } 
        
        if (!Input.GetKey(KeyCode.Q) && !Input.GetKey(KeyCode.E)) 
        {
            // Set idle trigger and reset other triggers to make sure there is a smooth transition.
            BodyAnimator.ResetTrigger("Lean Right"); 
            BodyAnimator.ResetTrigger("Lean Left"); 

            BodyAnimator.SetTrigger("Idle Camera"); 
        }



        //Reduce movement speed and scale when crouched.
        if (Input.GetKey(KeyCode.C))
        {
            MAnimator.ResetTrigger("Run");
            Movementspeed = 1.5f;
            player.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
        } 
        else if (Input.GetKeyUp(KeyCode.C)){

            Movementspeed = 3f;
            player.transform.localScale = new Vector3(1f, 1f, 1f);

            if (Input.GetKey(KeyCode.LeftShift)){
                Movementspeed = 8f;
            }
        }

        //Check if player is not crouching, leaning or aiming. If not then increase movement speed nad start running animation.
        if (Input.GetKey(KeyCode.LeftShift) && !Input.GetKey(KeyCode.C) && !Input.GetMouseButton(1) && !Input.GetKey(KeyCode.Q) && !Input.GetKey(KeyCode.E) && Input.GetKey(KeyCode.W))
        {
            BodyAnimator.ResetTrigger("Lean Right"); 
            BodyAnimator.ResetTrigger("Lean Left"); 
            MAnimator.ResetTrigger("Walk");
            MAnimator.ResetTrigger("idle");
            MAnimator.SetTrigger("Run");
        }

        // Increase movement speed when the lefshift button is being pressed, whilst the player us walking.
        if (Input.GetKey(KeyCode.W))
        {
            if (Input.GetKeyDown(KeyCode.LeftShift))
            {
                Movementspeed = 8f;
            }
        }

        //Stop moving when shift, W and C arent active.
        if(!Input.GetKey(KeyCode.LeftShift) && !Input.GetKey(KeyCode.C) && !Input.GetKey(KeyCode.W) && !Input.GetMouseButton(1))
        {
            MAnimator.ResetTrigger("Run");
            MAnimator.SetTrigger("idle");
            Movementspeed = 3f;
        }

        //Stop Running and continue walking.
        if(Input.GetKeyUp(KeyCode.LeftShift) && Input.GetKey(KeyCode.W))
        {
            MAnimator.ResetTrigger("idle");
            MAnimator.ResetTrigger("Run");         
            MAnimator.SetTrigger("Walk");
            Movementspeed = 3f;
        }


        //Stop moving when W key is released.
        if (Input.GetKeyUp(KeyCode.W))
        {
            MAnimator.ResetTrigger("Walk");
            MAnimator.SetTrigger("idle");
        } 

        //Check if only W key is pressed to begin walking.
        if (Input.GetKey(KeyCode.W) ^ Input.GetKeyUp(KeyCode.A) ^ Input.GetKeyUp(KeyCode.S) ^ Input.GetKeyUp(KeyCode.D) && !Input.GetKey(KeyCode.LeftShift))
        {
            MAnimator.ResetTrigger("idle");
            MAnimator.SetTrigger("Walk");
        } 

        //Reduce movement speed when ADS.
        if (Input.GetMouseButton(1)){
            MAnimator.ResetTrigger("Run");
            Movementspeed = 2f; 
        }    
    }

}