using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCamera : MonoBehaviour
{
    // Defining all public and private variables from the camera itself.
    float xRotation = 0f;
    public float mouseSens = 150;

    // Defining all public and private variables that refer to different GameObjects.
    public Transform player;
    public Transform Gun;

    void Start()
    {
        // Lock mouse in de middle of the screen so the player won't click out of the game.
        Cursor.lockState = CursorLockMode.Locked;
    }
    void Update()
    {
        // Get horizontal and vertical mouse inputs from the player.
       float MouseX = Input.GetAxis("Mouse X") * mouseSens * Time.deltaTime;
       float MouseY = Input.GetAxis("Mouse Y") * mouseSens * Time.deltaTime;

        xRotation -= MouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f);

        // Rotate player GameObject when moving the mouse on the horizontal axis.
        transform.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
        player.Rotate(Vector3.up * MouseX);
    }


}
