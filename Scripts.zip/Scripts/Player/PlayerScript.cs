using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class PlayerScript : MonoBehaviour
{
    // Defining all public variables from the Player GameObject itself.
    public float score = 0;

    // Defining all public variables that refer to different GameObjects.
    public static PlayerScript instance;
    public TextMeshProUGUI TextProScore;
    public TextMeshProUGUI TextProScoreOnDeath;


    void  Start()
    {
        // Check if there is already an instance of a Player Game0bject. If so, destroy it.
        if(instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
        // Make the current Player GameObject an instance.
            instance = this;
        }
        DontDestroyOnLoad(gameObject);
    }

    void Update()
    {
        // Update score on the UI of the alive and dead canvas;
        TextProScore.text = score + "";
        TextProScoreOnDeath.text = "Score: " + score;
    }
}
