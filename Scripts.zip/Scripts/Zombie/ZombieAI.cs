using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieAI : MonoBehaviour
{
    // Defining all public and private variables from the zombie itself.
    private bool dead;
    public float health = 50f;
    public int DamageAmount;
    private int index;
    public float within_range;
    public float dist;
    public float ZombieKillscore;
    public float givenScore;

    // Defining all public and private variables that refer to different GameObjects.
    private Animator Zanimator;
    private UnityEngine.AI.NavMeshAgent zombie;
    private GameObject objective;
    public Rigidbody[] Rigidbodies;
    public AudioSource currentGrowl;
    public AudioClip[] Growls;
    public GameObject[] Colliders;

    void Start()
    {

        dead = false;
        objective = GameObject.Find("Player");

        //get all necessary components
        zombie = GetComponent<UnityEngine.AI.NavMeshAgent>();
        Zanimator = GetComponent<Animator>();
        Rigidbodies = GetComponentsInChildren<Rigidbody>(); 
        gameObject.GetComponent<CapsuleCollider>().enabled = false; 

        //Start walking animation at random frame for more diversity.
        var state = Zanimator.GetCurrentAnimatorStateInfo(0);
        Zanimator.Play(state.fullPathHash, 0, Random.Range(0f, 1f));

        //Make all Rigidbodys inside the armature of the zombie on "IsKinematic". This way they wont collider with the mesh of the parent. (the zombie body itself)
        foreach(Rigidbody rb in Rigidbodies){
        rb.isKinematic = true;
        rb.detectCollisions = false;
        }

        CallAudio ();


    }


    void Update() 
    {

        //Check if the player is to far away te be "recognised" by the zombie.
        dist = Vector3.Distance(objective.transform.position, transform.position);
        if(dist <= within_range) {
            //If the player is close enough, and the zombie is not dead. The zombie wil start the chase animation, stop the idle animation and pathfind towards the player. 
            //If the zplayer is to far away, the NavMeshAgent will be disabled and the zombie wil play the idle animation on loop
            if (dead != true)
            {
                Zanimator.ResetTrigger("Idle");
                Zanimator.SetTrigger("Chase");
                gameObject.GetComponent<CapsuleCollider>().enabled = true; 
                WalkToPlayer();
            }
            } 
            else
            {
                Zanimator.ResetTrigger("Chase");
                Zanimator.SetTrigger("Idle");
                gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>().enabled = false;   
            }


        // Stop making sound when dead <-
        if (dead)
        {
            currentGrowl.Stop();
        }
    }

    public void Die()
    {   
            //A couple things happen when the Die() script is called. 
            //We start by unchecking the "IsKinematic" bool. This makes the RagDoll colliders react to collision again. 
            dead = true;
            foreach(Rigidbody rb in Rigidbodies){
            rb.isKinematic = false;
            rb.detectCollisions = true;
            }   
 
            //After that, we get and disable all the MeshColliders from the different body parts of the zombie.
            foreach(GameObject Collider in Colliders){
                Collider.GetComponent<MeshCollider>().enabled = false;
            }    
            //Then we disable the NavMeshAgent, Animaot and BoxCollider components from the zombie itself. 
            //This assures that the zombie wil fall with a realistic effect, instead of being pinned in mid air.
            gameObject.GetComponent<Animator>().enabled = false;
            gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>().enabled = false;   
            gameObject.GetComponent<CapsuleCollider>().enabled = false; 
            StartCoroutine(waiter());
    }

    void WalkToPlayer()
    {
            //Enable the NavMeshAgent to calculate a path to the player. Then walk to the player
            gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>().enabled = true;   
            zombie.SetDestination(objective.transform.position);

            //Stop the chase animation and start attacking when the player is close. 
            if (dist < 2.5)
            {
                gameObject.GetComponent<UnityEngine.AI.NavMeshAgent>().enabled = false;  
                Zanimator.ResetTrigger("Chase");
                Zanimator.ResetTrigger("Idle");
                Zanimator.SetTrigger("Attack");
                
                //enable the box collider to check for collisions against the player
                gameObject.GetComponent<CapsuleCollider>().enabled = true; 

            } else
            {
                gameObject.GetComponent<CapsuleCollider>().enabled = false; 
            }
    }

    public void TakeDamage(float amount){
        health -= amount;

        if (health <= 0f)
        {
            Die(); 
        }

        GameObject.Find("Player").GetComponent<PlayerScript>().score += amount;
    }


    //The Waiter IEmnumertator is called at the end of the Die() function to put the RagDoll colliders on "IsKinematic" again.
    //This improves performance because the game doesn't have to calculate collisions of dead zombies anymore.
    // It also means that the player can walk over dead zombies with ease.
    IEnumerator waiter()
    {
        //Wait for 5 seconds
        yield return new WaitForSeconds(5);
    
        foreach(Rigidbody rb in Rigidbodies){
            rb.isKinematic = true;
            rb.detectCollisions = false;
        } 
    }



    //Calls the MakeSound() function at a random amount of seconds to add diversity.
    void CallAudio()
    {
        Invoke ("MakeSound", Random.Range(1, 15));
    }

    public void MakeSound(){

        //First a random audio clip is chosen from the audiosources array. (Growls[])
        index = Random.Range (0, Growls.Length);
        currentGrowl.clip = Growls[index];

        //After that the game checks if there isn't already an audio playing.
        if (!currentGrowl.isPlaying)
        {
            //If there isn't an audio being played, plays audio from random time in the clip
            currentGrowl.time = Random.Range(0f, currentGrowl.clip.length);
            currentGrowl.Play();
        }

        //does not call a new audio when zombie is dead.
        if (!dead){
        CallAudio();
        }
    }

    //Check if the zombie collides with the player
    void OnCollisionEnter(Collision collision)
    {
        PlayerHealthSystem other = collision.gameObject.GetComponent<PlayerHealthSystem>();
        if (other)
        {
            //Get Health flaot from the PlayerHealthSystem scirpt and remove 10 Health;
            other.GetComponent<PlayerHealthSystem>().Health -= 10f;
        }
    }

}
