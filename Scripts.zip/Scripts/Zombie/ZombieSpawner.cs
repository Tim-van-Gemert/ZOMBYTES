using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZombieSpawner : MonoBehaviour
{
    // Defining all public and private variables from the spawner itself.
    public float timeToSpawn;
    private float currentTimeToSpawn;

    // Defining all public and private variables that refer to different GameObjects.
    public GameObject Zombie;

    void Start()
    {
        // Start the Corountine to destroy the spawner after half a minute.
        StartCoroutine(DestroySpawner());
    }

    // Instantiate a zombie at the position and rotation of the spawner every time the SpawnerFunction() is called.
    private void SpawnerFunction()
    {
        GameObject NewZombie = Instantiate(Zombie, transform.position, transform.rotation);
    }

    void Update()
    {

        // Check if the spawner can instantiate a new zombie by checking if the cooldown is equal to 0.
        if(currentTimeToSpawn > 0)
        {
            currentTimeToSpawn -= Time.deltaTime;
        }
        else
        {
            SpawnerFunction();
            currentTimeToSpawn = timeToSpawn;
        }



    }

    IEnumerator DestroySpawner()
    {
        yield return new WaitForSeconds(30);
        Destroy(gameObject);
    }

}
