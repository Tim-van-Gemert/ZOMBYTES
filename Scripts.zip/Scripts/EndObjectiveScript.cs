using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndObjectiveScript : MonoBehaviour
{
    // Defining all public and private variables from the End Objective itself.
    public float health = 4000f;

    // Defining all public and private variables that refer to different GameObjects.
    private Animator Oanimator;
    public ZombieAI[] Zombies;
    private GameObject wonScreen;
    private GameObject aliveScreen;


    void Start()
    { 
        // Define the YOU WON! and alice canvas.
        wonScreen =  GameObject.Find("Won Screen");
        aliveScreen = GameObject.Find("Alive Screen");
        wonScreen.SetActive(false);

        // Define the animator of the gameobject
        Oanimator = GetComponent<Animator>();
    }


    // Check if the gameobjects health is equal or lower then 0 every time the TakeDamage function is called. If so, call the Die() function.
    public void TakeDamage(float amount){
        health -= amount;
        if (health <= 0f)
        {
            health = 0f;
            Die(); 
        }
    }

    // Check for all zombies in the scene, and push them into an array. We have to do this in the update function because new zombies are being spawned while the level is played.
    void Update()
    {
        Zombies =  FindObjectsOfType(typeof(ZombieAI)) as ZombieAI[];
    }
    

    // Get each zombie in the scene and call their Die() function when the End Objective has died.
    void Die()
    {   
        foreach(ZombieAI Zombie in Zombies)
        {
            Zombie.Die();
            StartCoroutine(FinishGame());

        }

        Oanimator.SetTrigger("Die");
    }

    IEnumerator FinishGame()
    {
        //Wait for 2 seconds
        yield return new WaitForSeconds(2);

        // Remove lock from cursor so the payer can click on the menu buttons.
        Cursor.lockState = CursorLockMode.None;

        // Show YOU WON! canvas instead of the alive canvas. 
        aliveScreen.SetActive(false);
        wonScreen.SetActive(true);

        // Freeze time.
        Time.timeScale = 0;
    }
}
