using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneToLoad : MonoBehaviour
{
    // Defining all public and private variables from the SceneManager itself.
    private float transitionTimeLevel = 2;
    private float transitionTimeGame = 31;
    public string sceneToLoad;
    public bool hasEntered;

    // Defining all public and private variables that refer to different GameObjects.
    private Animator transition;

    void Start()
    {
        // Define the animator from the sceneloader GameObject.
        transition = GameObject.Find("SceneLoader").GetComponent<Animator>();
    }


    private void OnTriggerEnter(Collider other)
    {   
        //Check if the player has collided with the hitbox of the sceneloader. If so, Load the next level.
        if (other.gameObject.CompareTag("Player") && !hasEntered) {
            hasEntered = true;

            // The SceneManeger knows wich level to load by searching for the next level in the build index.
            StartCoroutine(LoadLevel(SceneManager.GetActiveScene().buildIndex + 1));
        }
    }

    IEnumerator LoadLevel(int LevelIndex)
    {

        if (LevelIndex > 1)
        {
            // Start short transiton when the levels built index is higher then 1. We have to define this because we want to show the intro when loading the first level.
            transition.SetTrigger("StartLevelFadeIn"); 
            transitionTimeLevel = 2; 

            // Reset hasEntered bool so the player can walk into a new sceneloader again.
            hasEntered = false; 
        }

        yield return new WaitForSeconds(transitionTimeLevel);
        SceneManager.LoadScene(LevelIndex);
        StartCoroutine(StopCutscene());
    }

    IEnumerator StopCutscene()
    {
        // The game stops the transtition custscene from playing again after loading in by resetting the trigger.
        transition.ResetTrigger("StartLevelFadeIn");
        yield return new WaitForSeconds(transitionTimeLevel);
    }


}
