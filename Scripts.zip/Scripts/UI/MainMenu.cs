using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    // Defining all public and private variables from the main menu itself.
    private bool NIsPressed;

    // Defining all public and private variables that refer to different GameObjects.
    public Animator transition;
    private GameObject diedScreen;
    private GameObject aliveScreen;

    void Start(){
        // Remove lock from cursor so the player can press buttons in the menu.
        Cursor.lockState = CursorLockMode.None;
        NIsPressed = false;

        //Define the alive and dead canvas.
        diedScreen =  GameObject.Find("Player").GetComponent<PlayerHealthSystem>().diedScreen;
        aliveScreen = GameObject.Find("Player").GetComponent<PlayerHealthSystem>().aliveScreen;
    }

    public void PlayGame()
    {
        // Reset the necesarry variables and bools to start from a clean slate again.
        NIsPressed = false;
        GameObject.Find("Player").GetComponent<PlayerScript>().score = 0;
        GameObject.Find("Player").GetComponent<PlayerHealthSystem>().Health = 100;
        GameObject.Find("sniper rifle 2_prefab").GetComponent<GunScript>().checkIfPlayerIsAlive = true;
        GameObject.Find("sniper rifle 2_prefab").GetComponent<GunScript>().AmmoInClip = 50;
        Time.timeScale = 1;

        //Switch between active canvases.
        diedScreen.SetActive(false);
        aliveScreen.SetActive(true);
        GameObject.Find("Background").SetActive(false);

        // load level and starting animation.
        StartCoroutine(LoadLevel());
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    public void BackToMenu()
    {
        // Load main menu scene.
        SceneManager.LoadScene("MenuScene");
    }

    void Update()
    {
        // Check if player has pressed the N key to skip starting custscene. if so, stop the Loadlevel() coroutine and reset the intro animation trigger and play the Start level tranistion instead.
        if (Input.GetKey(KeyCode.N) && !NIsPressed)
        {
            NIsPressed = true;
            transition.ResetTrigger("StartGame");
            transition.SetTrigger("StartLevel");
            SceneManager.LoadScene("Level 1");
            StopCoroutine(LoadLevel());
        }
    }


      IEnumerator LoadLevel()
    {
        transition.ResetTrigger("StartLevel");
        transition.SetTrigger("StartGame");
        yield return new WaitForSeconds(32);
        SceneManager.LoadScene("Level 1");
    }
}
