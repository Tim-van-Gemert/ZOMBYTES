using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneEntrance : MonoBehaviour
{
    // Defining all private variables that refer to different GameObjects.
    private Animator transition;
    private GameObject gun;

    void Start()
    {
            // Spawn player at the location and rotation of the gameObject.
            PlayerScript.instance.transform.position = transform.position;
            PlayerScript.instance.transform.eulerAngles = transform.eulerAngles;

            // Reset the ammo count of the players gun.
            gun = GameObject.Find("sniper rifle 2_prefab");
            gun.GetComponent<GunScript>().Ammo = 300;

    }
}
